
<!-- ////////////////////////////////////////////////////////////////////////////////////// -->
    <?php
function camposelect($campo,$tabla,$id)
{  
    $servername = "localhost";
    $username = "root";  $password = "";   $dbname = "portal21a";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 
    $sql = "SELECT $id,$campo FROM $tabla";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    echo "<select name='$campo'>";
    while($row = $result->fetch_assoc())
     {
        echo  "<option value='".$row["$campo"]. "'>".$row["$campo"]."</option>";      
        }
    echo "</select>";
    } $conn->close();
}
///////////////////////////////////////////////////////////////
function editselect($campo,$tabla,$id,$selected)
{  
    $servername = "localhost";
    $username = "root";  $password = "";   $dbname = "portal21a";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 
    
    $sql = "SELECT $id,$campo FROM $tabla";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    echo "<select name='$campo' >";
    while($row = $result->fetch_assoc())
        {
            echo  "<option value='".$row["$campo"]."'";
             if($row["$campo"]==$selected){
                echo  " selected ";  
             }
            echo ">".$row["$campo"]."</option>";   
        }
    echo "</select>";
    } $conn->close();
}

    ?>